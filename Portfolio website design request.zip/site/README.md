# jakepatterson.cv

Static portfolio site. No build step — every file here is served as-is.

    index.html      the site (self-contained page + its logic)
    support.js      runtime the page loads
    ds/styles.css   design tokens and components
    assets/         project photos + CV PDF
    CNAME           custom domain for GitHub Pages
    .nojekyll       stops GitHub from filtering files

## Deploy (GitHub Pages)

1. Create a repo, e.g. `jakepatterson.github.io` (or any name — Pages works either way).
2. Commit the contents of this folder to the repo root on `main`.
3. Repo → Settings → Pages → Source: "Deploy from a branch", Branch: `main`, Folder: `/ (root)`.
4. Settings → Pages → Custom domain: `jakepatterson.cv`, then tick "Enforce HTTPS" once the certificate is issued.

## DNS at your domain registrar

Apex domain `jakepatterson.cv` — four A records:

    185.199.108.153
    185.199.109.153
    185.199.110.153
    185.199.111.153

(Optional, IPv6 — four AAAA records:)

    2606:50c0:8000::153
    2606:50c0:8001::153
    2606:50c0:8002::153
    2606:50c0:8003::153

And a CNAME for `www` pointing at `<your-github-username>.github.io.`

DNS can take up to 24 hours to propagate; the HTTPS certificate is issued after that.

## Updating content

Edit `index.html`. The project list lives in the `PROJECTS` array near the bottom of the file;
photos are `assets/<slug>-1.png` … `-3.png`. Replace those files with your originals
(same names) and the site picks them up.
